//! What will render my component?
//* State / props

//! What is the direction of the props?
//* Top to bottom / parent to son

//! props is a read-only object

//! Where should I put my props when it is passed by the father?
//* At the attribute

//! Where should I put my children (prop) when it is passed by the father?
//* between the opening and closing tags

//! Who is the parent component?
//* Component who render another component (which he's the son).

//! Where should I put my state?
//* Where I need to see the value Or change the value
//* A the closest junction!!! for all of my usages.

//! How would I change something in the father from the son?
//*
